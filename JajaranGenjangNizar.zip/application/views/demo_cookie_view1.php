<html>
<head>
<title>Demo Membuat dan Membaca Cookie </title>
</head>
<body>
<h2>Demo Membuat dan membaca Cookie - Halaman 1</h2>

Nilai Myvar : <?php echo get_cookie('myvar'); ?><br />
<p>
<a href="demo_cookie/halaman2">Halaman2</a>
</p>

</body>
</html>

