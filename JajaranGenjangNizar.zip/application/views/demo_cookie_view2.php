<html>
<head>
<title>Demo Membuat dan Membaca Cookie </title>
</head>
<body>
<h2>Demo Membuat dan membaca Cookie - Halaman 2</h2>

Nilai Myvar : <?php echo get_cookie('myvar'); ?><br />
<p>
<a href="demo_cookie/halaman2">Halaman1</a>
</p>

</body>
</html>
