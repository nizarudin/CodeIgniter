<html>
<head><title>Controller, Model dan View </title></head>
<body>
<h2><?php echo $teks; ?></h2>
<h3>Ini adalah aplikasi CI dengan Controller, Model dan View</h3>
</body>
</html>
