<html>
<head>
<title>Demo Model</title>
</head>
<body>
<h2>Luas dan keliling Jajaran Genjang</h2>

<form action="Jajaran" method="post">
 Masukkan nilai Tinggi: <br />
<input type="text" name="tinggi" /><br />
Masukkan nilai Alas: <br />
<input type="text" name="alas" /><br />
Masukkan nilai SisiA: <br />
<input type="text" name="sisiA" /><br />
Masukkan nilai SisiB: <br />
<input type="text" name="sisiB" /><br />
<br />
<input type="submit" name="btnSubmit" value="Hitung" />
</form>
</body>
</html>