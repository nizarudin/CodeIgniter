<html>
<head>
<title>Demo Model</title>
</head>
<body>
<h2>Luas dan keliling lingkaran</h2>

<form action="lingkaran" method="post">
Masukkan nilai jari-jari: <br />
<input type="text" name="jari2" />
<input type="submit" name="btnSubmit" value="Hitung" />
</form>
</body>
</html>