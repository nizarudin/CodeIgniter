<?php
class Hello_model extends CI_Model{
    //Mendefinisikan properti dengan nama User

    public $str = "Hello NizarGanteng";
}
?>